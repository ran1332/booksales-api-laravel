<?php

namespace Database\Seeders;

use App\Models\Book;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Book::create([
             'tittle' => 'The Art of Laravel',
                'description' => 'Panduan lengkap membangun aplikasi modern menggunakan Laravel Framework.',
                'price' => 120000,
                'stock' => 10,
                'cover_photo' => 'art-of-laravel.jpg',
                'genre_id' => 1,
                'author_id' => 1,
        ]);

        Book::create([
            'tittle' => 'Mastering PHP',
                'description' => 'Buku ini membahas PHP dari dasar hingga konsep lanjutan.',
                'price' => 95000,
                'stock' => 15,
                'cover_photo' => 'mastering-php.jpg',
                'genre_id' => 2,
                'author_id' => 2,
        ]);

        Book::create([
            'tittle' => 'Web Development for Beginners',
                'description' => 'Pelajari HTML, CSS, dan JavaScript untuk membangun website modern.',
                'price' => 80000,
                'stock' => 20,
                'cover_photo' => 'web-dev-beginners.jpg',
                'genre_id' => 3,
                'author_id' => 3,
        ]);

        Book::create([
            'tittle' => 'API Development with Laravel',
                'description' => 'Panduan membuat RESTful API menggunakan Laravel Sanctum dan Resource.',
                'price' => 100000,
                'stock' => 12,
                'cover_photo' => 'api-laravel.jpg',
                'genre_id' => 1,
                'author_id' => 5,
        ]);
    }
}
