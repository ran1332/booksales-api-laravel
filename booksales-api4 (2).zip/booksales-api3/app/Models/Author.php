<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
    public static function allAuthors()
    {
        return [
            ['id' => 1, 'name' => 'J.K. Rowling', 'country' => 'United Kingdom'],
            ['id' => 2, 'name' => 'Isaac Asimov', 'country' => 'Russia/USA'],
            ['id' => 3, 'name' => 'Nicholas Sparks', 'country' => 'USA'],
            ['id' => 4, 'name' => 'Agatha Christie', 'country' => 'United Kingdom'],
            ['id' => 5, 'name' => 'Haruki Murakami', 'country' => 'Japan'],
        ];
    }
}
