<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Author</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 40px; }
        table { width: 80%; border-collapse: collapse; background: #fff; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background: #333; color: #fff; }
        h1 { margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Daftar Author</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Penulis</th>
                <th>Negara</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($author['id']); ?></td>
                    <td><?php echo e($author['name']); ?></td>
                    <td><?php echo e($author['country']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\booksales-apk\resources\views/authors.blade.php ENDPATH**/ ?>