<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    // tambahkan method statis allBooks()
    public static function allBooks()
    {
        return [
            ['title' => 'Laravel for Beginners', 'author' => 'John Doe'],
            ['title' => 'Mastering PHP', 'author' => 'Jane Smith'],
            ['title' => 'Web Programming 101', 'author' => 'Alan Walker'],
            ['title' => 'Bumi', 'author' => 'Tere Liye'],
            ['title' => 'Dilan 1990', 'author' => 'Pidi Baiq']
        ];
    }
}