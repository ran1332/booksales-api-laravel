<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use Illuminate\Support\Facades\Validator;
use Exception; // Diperlukan untuk penanganan try-catch

class BookController extends Controller
{
    /**
     * Tampilkan daftar semua buku (GET /api/books).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        // Mengambil semua data buku dari database
        $books = Book::all();

        // Mengembalikan respons JSON
        return response()->json([
            "success" => true,
            "message" => "Get All Resources successfully!",
            "data" => $books
        ], 200);
    }

    /**
     * Simpan buku baru ke storage (POST /api/books).
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // 1. Validasi Data
        $validator = Validator::make($request->all(), [
            'title'       => 'required|string|max:100',
            'description' => 'required|string',
            'price'       => 'required|numeric',
            'stock'       => 'required|integer',
            // Aturan file upload
            'cover_photo' => 'required|image|mimes:jpeg,jpg,png|max:2048',
            // Aturan ID asing (foreign key) - TELAH DIPERBAIKI SINTAKSNYA
            'genre_id'    => 'required|exists:genres,id',
            'author_id'   => 'required|exists:authors,id',
        ]);

        // 2. Cek Kegagalan Validasi
        if ($validator->fails()) {
            return response()->json([
                "success" => false,
                "message" => $validator->errors(),
            ], 422);
        }

        $cover_photo_path = null;

        // 3. Unggah File (dengan pengecekan & penanganan error)
        if ($request->hasFile('cover_photo')) {
            try {
                $image = $request->file('cover_photo');
                // Simpan file ke storage/app/public/books
                $cover_photo_path = $image->store('books', 'public');

            } catch (Exception $e) {
                // Tangani error jika gagal menyimpan file (misalnya izin folder)
                return response()->json([
                    "success" => false,
                    "message" => "Gagal menyimpan file: " . $e->getMessage(),
                ], 500); // 500 Internal Server Error
            }
        }

        // 4. Masukkan Data ke Database
        try {
            $book = Book::create([
                'title'       => $request->title,
                'description' => $request->description,
                'price'       => $request->price,
                'stock'       => $request->stock,
                'cover_photo' => $cover_photo_path, // Path file disimpan di sini
                'genre_id'    => $request->genre_id,
                'author_id'   => $request->author_id,
            ]);
            
            // 5. Respons Sukses
            return response()->json([
                'success' => true,
                'message' => "Resource added successfully!",
                'data' => $book,
            ], 201); // 201 Created

        } catch (Exception $e) {
            // Tangani error jika gagal menyimpan data ke DB
            return response()->json([
                "success" => false,
                "message" => "Gagal menyimpan data buku: " . $e->getMessage(),
            ], 500);
        }
    }
}