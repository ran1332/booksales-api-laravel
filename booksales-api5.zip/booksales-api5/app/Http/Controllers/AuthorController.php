<?php

namespace App\Http\Controllers;

use App\Models\Author;
use Illuminate\Http\Request;

class AuthorController extends Controller
{
    // SHOW
    public function show($id)
    {
        $author = Author::find($id);

        if (!$author) {
            return response()->json([
                'success' => false,
                'message' => 'Author tidak ditemukan.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $author
        ]);
    }

    // UPDATE
    public function update(Request $request, $id)
    {
        $author = Author::find($id);

        if (!$author) {
            return response()->json([
                'success' => false,
                'message' => 'Author tidak ditemukan.'
            ], 404);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'bio'  => 'nullable|string'
        ]);

        $author->update($request->only(['name', 'bio']));

        return response()->json([
            'success' => true,
            'message' => 'Author berhasil diperbarui.',
            'data' => $author
        ]);
    }

    // DESTROY
    public function destroy($id)
    {
        $author = Author::find($id);

        if (!$author) {
            return response()->json([
                'success' => false,
                'message' => 'Author tidak ditemukan.'
            ], 404);
        }

        $author->delete();

        return response()->json([
            'success' => true,
            'message' => 'Author berhasil dihapus.'
        ]);
    }
}
