<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Genre</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 40px; }
        table { width: 80%; border-collapse: collapse; background: #fff; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        th { background: #333; color: #fff; }
        h1 { margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Daftar Genre</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Genre</th>
                <th>Deskripsi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($genre['id']); ?></td>
                    <td><?php echo e($genre['name']); ?></td>
                    <td><?php echo e($genre['description']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\booksales-apk\resources\views/genres.blade.php ENDPATH**/ ?>